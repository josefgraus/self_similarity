#!/bin/bash
echo stripping $1
strip -x $1
